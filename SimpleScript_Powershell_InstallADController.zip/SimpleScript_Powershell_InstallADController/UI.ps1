# UI.ps1

function Create-MyForm {
    Add-Type -AssemblyName System.Windows.Forms

	#
	# Main Form
	#
    $FormMain = New-Object System.Windows.Forms.Form
    $FormMain.Text = "Install First AD Controller in a new forest"
    $FormMain.Size = '800,550'
	# 
	# LblFormMain_Titre
	#
	$LblFormMain_Titre = New-object System.Windows.Forms.Label
	$LblFormMain_Titre.AutoSize = $True
	$LblFormMain_Titre.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 18,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_Titre.Location = New-Object System.Drawing.Point(243, 22)
	$LblFormMain_Titre.Name = "LblFormMain_Titre"
	$LblFormMain_Titre.Size = New-Object System.Drawing.Size(312, 29)
	$LblFormMain_Titre.TabIndex = 0
	$LblFormMain_Titre.Text = "Install First AD Controller in a new forest"
	#
	# LblFormMain_DomainName
	#
	$LblFormMain_DomainName = New-object System.Windows.Forms.Label
	$LblFormMain_DomainName.AutoSize = $True
	$LblFormMain_DomainName.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_DomainName.Location = New-Object System.Drawing.Point(28, 96)
	$LblFormMain_DomainName.Name = "LblFormMain_DomainName"
	$LblFormMain_DomainName.Size = New-Object System.Drawing.Size(112, 20)
	$LblFormMain_DomainName.TabIndex = 1
	$LblFormMain_DomainName.Text = "Domain name:"
	#
	# LblFormMain_ServerName
	#
	$LblFormMain_ServerName = New-object System.Windows.Forms.Label
	$LblFormMain_ServerName.AutoSize = $True
	$LblFormMain_ServerName.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerName.Location = New-Object System.Drawing.Point(28, 130)
	$LblFormMain_ServerName.Name = "LblFormMain_ServerName"
	$LblFormMain_ServerName.Size = New-Object System.Drawing.Size(103, 20)
	$LblFormMain_ServerName.TabIndex = 2
	$LblFormMain_ServerName.Text = "Server name:"
	#
	# LblFormMain_ServerPassword
	#
	$LblFormMain_ServerPassword = New-object System.Windows.Forms.Label
	$LblFormMain_ServerPassword.AutoSize = $True
	$LblFormMain_ServerPassword.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerPassword.Location = New-Object System.Drawing.Point(28, 163)
	$LblFormMain_ServerPassword.Name = "LblFormMain_ServerPassword"
	$LblFormMain_ServerPassword.Size = New-Object System.Drawing.Size(131, 20)
	$LblFormMain_ServerPassword.TabIndex = 3
	$LblFormMain_ServerPassword.Text = "Safe mode administrator password:"
	#
	# LblFormMain_ServerNetworkIpAddress
	#
	$LblFormMain_ServerNetworkIpAddress = New-object System.Windows.Forms.Label
	$LblFormMain_ServerNetworkIpAddress.AutoSize = $True
	$LblFormMain_ServerNetworkIpAddress.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerNetworkIpAddress.Location = New-Object System.Drawing.Point(28, 230)
	$LblFormMain_ServerNetworkIpAddress.Name = "LblFormMain_ServerNetworkIpAddress"
	$LblFormMain_ServerNetworkIpAddress.Size = New-Object System.Drawing.Size(200, 20)
	$LblFormMain_ServerNetworkIpAddress.TabIndex = 4
	$LblFormMain_ServerNetworkIpAddress.Text = "Server network ip address:"
	#
	# LblFormMain_ServerNetworkMask
	#
	$LblFormMain_ServerNetworkMask = New-object System.Windows.Forms.Label
	$LblFormMain_ServerNetworkMask.AutoSize = $True
	$LblFormMain_ServerNetworkMask.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerNetworkMask.Location = New-Object System.Drawing.Point(28, 261)
	$LblFormMain_ServerNetworkMask.Name = "LblFormMain_ServerNetworkMask"
	$LblFormMain_ServerNetworkMask.Size = New-Object System.Drawing.Size(161, 20)
	$LblFormMain_ServerNetworkMask.TabIndex = 5
	$LblFormMain_ServerNetworkMask.Text = "Server network mask:"
	#
	# LblFormMain_ServerEthernetAdapterToUse
	#
	$LblFormMain_ServerEthernetAdapterToUse = New-object System.Windows.Forms.Label
	$LblFormMain_ServerEthernetAdapterToUse.AutoSize = $True
	$LblFormMain_ServerEthernetAdapterToUse.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerEthernetAdapterToUse.Location = New-Object System.Drawing.Point(28, 196)
	$LblFormMain_ServerEthernetAdapterToUse.Name = "LblFormMain_ServerEthernetAdapterToUse"
	$LblFormMain_ServerEthernetAdapterToUse.Size = New-Object System.Drawing.Size(230, 20)
	$LblFormMain_ServerEthernetAdapterToUse.TabIndex = 6
	$LblFormMain_ServerEthernetAdapterToUse.Text = "Server ethernet adapter to use:"
	#
	# $LblFormMain_ServerGateway
	#
	$LblFormMain_ServerGateway = New-object System.Windows.Forms.Label
	$LblFormMain_ServerGateway.AutoSize = $True
	$LblFormMain_ServerGateway.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerGateway.Location = New-Object System.Drawing.Point(28, 293)
	$LblFormMain_ServerGateway.Name = "LblFormMain_ServerGateway"
	$LblFormMain_ServerGateway.Size = New-Object System.Drawing.Size(122, 20)
	$LblFormMain_ServerGateway.TabIndex = 7
	$LblFormMain_ServerGateway.Text = "Server gateway:"
	#
	# $LblFormMain_ServerPrimaryDns
	#
	$LblFormMain_ServerPrimaryDns = New-object System.Windows.Forms.Label
	$LblFormMain_ServerPrimaryDns.AutoSize = $True
	$LblFormMain_ServerPrimaryDns.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerPrimaryDns.Location = New-Object System.Drawing.Point(28, 328)
	$LblFormMain_ServerPrimaryDns.Name = "LblFormMain_ServerPrimaryDns"
	$LblFormMain_ServerPrimaryDns.Size = New-Object System.Drawing.Size(144, 20)
	$LblFormMain_ServerPrimaryDns.TabIndex = 8
	$LblFormMain_ServerPrimaryDns.Text = "Server primary dns:"
	#
	# $LblFormMain_ServerSecondaryDns
	#
	$LblFormMain_ServerSecondaryDns = New-object System.Windows.Forms.Label
	$LblFormMain_ServerSecondaryDns.AutoSize = $True
	$LblFormMain_ServerSecondaryDns.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$LblFormMain_ServerSecondaryDns.Location = New-Object System.Drawing.Point(28, 357)
	$LblFormMain_ServerSecondaryDns.Name = "LblFormMain_ServerSecondaryDns"
	$LblFormMain_ServerSecondaryDns.Size = New-Object System.Drawing.Size(166, 20)
	$LblFormMain_ServerSecondaryDns.TabIndex = 9
	$LblFormMain_ServerSecondaryDns.Text = "Server secondary dns:"
	#
	# $TxtBoxFormMain_DomainName
	#
	$TxtBoxFormMain_DomainName = New-object System.Windows.Forms.TextBox
	$TxtBoxFormMain_DomainName.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_DomainName.Location = New-Object System.Drawing.Point(294, 93)
    $TxtBoxFormMain_DomainName.Name = "TxtBoxFormMain_DomainName"
    $TxtBoxFormMain_DomainName.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_DomainName.TabIndex = 10
	#
    # $TxtBoxFormMain_ServerName
    #
	$TxtBoxFormMain_ServerName = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerName.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerName.Location = New-Object System.Drawing.Point(294, 127)
    $TxtBoxFormMain_ServerName.Name = "TxtBoxFormMain_ServerName"
    $TxtBoxFormMain_ServerName.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerName.TabIndex = 11
	#
    # $TxtBoxFormMain_ServerPassword
    #
	$TxtBoxFormMain_ServerPassword = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerPassword.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerPassword.Location = New-Object System.Drawing.Point(294, 160)
    $TxtBoxFormMain_ServerPassword.Name = "TxtBoxFormMain_ServerPassword"
    $TxtBoxFormMain_ServerPassword.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerPassword.TabIndex = 12
	#
    # $TxtBoxFormMain_ServerNetworkIpAddress
    #
	$TxtBoxFormMain_ServerNetworkIpAddress = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerNetworkIpAddress.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerNetworkIpAddress.Location = New-Object System.Drawing.Point(294, 227)
    $TxtBoxFormMain_ServerNetworkIpAddress.Name = "TxtBoxFormMain_ServerNetworkIpAddress"
    $TxtBoxFormMain_ServerNetworkIpAddress.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerNetworkIpAddress.TabIndex = 13
	#
    # $TxtBoxFormMain_ServerNetworkMask
    #
	$TxtBoxFormMain_ServerNetworkMask = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerNetworkMask.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerNetworkMask.Location = New-Object System.Drawing.Point(294, 258)
    $TxtBoxFormMain_ServerNetworkMask.Name = "TxtBoxFormMain_ServerNetworkMask"
    $TxtBoxFormMain_ServerNetworkMask.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerNetworkMask.TabIndex = 14
    #
    # $TxtBoxFormMain_ServerGateway
    #
	$TxtBoxFormMain_ServerGateway  = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerGateway.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerGateway.Location = New-Object System.Drawing.Point(294, 290)
    $TxtBoxFormMain_ServerGateway.Name = "TxtBoxFormMain_ServerGateway"
    $TxtBoxFormMain_ServerGateway.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerGateway.TabIndex = 15
    #
    # $TxtBoxFormMain_ServerPrimaryDns
    #
	$TxtBoxFormMain_ServerPrimaryDns  = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerPrimaryDns.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerPrimaryDns.Location = New-Object System.Drawing.Point(294, 325)
    $TxtBoxFormMain_ServerPrimaryDns.Name = "TxtBoxFormMain_ServerPrimaryDns"
    $TxtBoxFormMain_ServerPrimaryDns.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerPrimaryDns.TabIndex = 16
    #
    # $TxtBoxFormMain_ServerSecondaryDns
    #
	$TxtBoxFormMain_ServerSecondaryDns = New-object System.Windows.Forms.TextBox
    $TxtBoxFormMain_ServerSecondaryDns.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $TxtBoxFormMain_ServerSecondaryDns.Location = New-Object System.Drawing.Point(294, 354)
    $TxtBoxFormMain_ServerSecondaryDns.Name = "TxtBoxFormMain_ServerSecondaryDns"
    $TxtBoxFormMain_ServerSecondaryDns.Size = New-Object System.Drawing.Size(436, 26)
    $TxtBoxFormMain_ServerSecondaryDns.TabIndex = 17
	#
    # $LstBoxFormMain_ServerEthernetAdapterToUse
    #
	$LstBoxFormMain_ServerEthernetAdapterToUse = New-object System.Windows.Forms.ListBox
	$LstBoxFormMain_ServerEthernetAdapterToUse.FormattingEnabled = $True
	$LstBoxFormMain_ServerEthernetAdapterToUse.ItemHeight = 20;
	$LstBoxFormMain_ServerEthernetAdapterToUse.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
    $LstBoxFormMain_ServerEthernetAdapterToUse.Location = New-Object System.Drawing.Point(294, 192)
    $LstBoxFormMain_ServerEthernetAdapterToUse.Name = "LstBoxFormMain_ServerEthernetAdapterToUse"
    $LstBoxFormMain_ServerEthernetAdapterToUse.Size = New-Object System.Drawing.Size(436, 24)
    $LstBoxFormMain_ServerEthernetAdapterToUse.TabIndex = 18
	#
    # $BtnFormMain_InstallADDS
    #
	$BtnFormMain_InstallADDS = New-object System.Windows.Forms.Button
	$BtnFormMain_InstallADDS.Font = New-Object System.Drawing.Font("Microsoft Sans Serif", 12,[System.Drawing.FontStyle]::Regular,[System.Drawing.GraphicsUnit]::Point, 0)
	$BtnFormMain_InstallADDS.Location = New-Object System.Drawing.Point(373, 405)
	$BtnFormMain_InstallADDS.Name = "BtnFormMain_InstallADDS"
	$BtnFormMain_InstallADDS.Size = New-Object System.Drawing.Size(213, 33)
	$BtnFormMain_InstallADDS.TabIndex = 19
	$BtnFormMain_InstallADDS.Text = "Install ADDS"
	$BtnFormMain_InstallADDS.UseVisualStyleBackColor = $True
	
	$FormMain.Controls.Add($LblFormMain_Titre)
	$FormMain.Controls.Add($LblFormMain_DomainName)
	$FormMain.Controls.Add($LblFormMain_ServerName)
	$FormMain.Controls.Add($LblFormMain_ServerPassword)
	$FormMain.Controls.Add($LblFormMain_ServerNetworkIpAddress)
	$FormMain.Controls.Add($LblFormMain_ServerNetworkMask)
	$FormMain.Controls.Add($LblFormMain_ServerEthernetAdapterToUse)
	$FormMain.Controls.Add($LblFormMain_ServerGateway)
	$FormMain.Controls.Add($LblFormMain_ServerPrimaryDns)
	$FormMain.Controls.Add($LblFormMain_ServerSecondaryDns)
	$FormMain.Controls.Add($TxtBoxFormMain_DomainName)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerName)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerPassword)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerNetworkIpAddress)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerNetworkMask)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerGateway)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerPrimaryDns)
	$FormMain.Controls.Add($TxtBoxFormMain_ServerSecondaryDns)
	$FormMain.Controls.Add($LstBoxFormMain_ServerEthernetAdapterToUse)
	$FormMain.Controls.Add($BtnFormMain_InstallADDS)
	
    # On retourne une table contenant la form et ses contrôles
    return @{
        FormMain = $FormMain
		TxtBoxFormMain_DomainName = $TxtBoxFormMain_DomainName
		TxtBoxFormMain_ServerName = $TxtBoxFormMain_ServerName
		TxtBoxFormMain_ServerPassword = $TxtBoxFormMain_ServerPassword
		TxtBoxFormMain_ServerNetworkIpAddress = $TxtBoxFormMain_ServerNetworkIpAddress
		TxtBoxFormMain_ServerNetworkMask = $TxtBoxFormMain_ServerNetworkMask
		TxtBoxFormMain_ServerGateway = $TxtBoxFormMain_ServerGateway
		TxtBoxFormMain_ServerPrimaryDns = $TxtBoxFormMain_ServerPrimaryDns
		TxtBoxFormMain_ServerSecondaryDns = $TxtBoxFormMain_ServerSecondaryDns
		LstBoxFormMain_ServerEthernetAdapterToUse = $LstBoxFormMain_ServerEthernetAdapterToUse
        BtnFormMain_InstallADDS = $BtnFormMain_InstallADDS
    }
}
