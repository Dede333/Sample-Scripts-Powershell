# Logic.ps1

$ScriptName = "Install_ADDS.ps1"

function On-Click_BtnFormMain_InstallADDS {
	 param (
        [hashtable]$FormControls
	)
	
	# R�cup�ration des valeurs du formulaire
    $DomainName     = $FormControls.TxtBoxFormMain_DomainName.Text
    $ServerName     = $FormControls.TxtBoxFormMain_ServerName.Text
    $ServerPassword = $FormControls.TxtBoxFormMain_ServerPassword.Text
    $IPAddress      = $FormControls.TxtBoxFormMain_ServerNetworkIpAddress.Text
    $Netmask        = $FormControls.TxtBoxFormMain_ServerNetworkMask.Text
    $Gateway        = $FormControls.TxtBoxFormMain_ServerGateway.Text
    $PrimaryDNS     = $FormControls.TxtBoxFormMain_ServerPrimaryDns.Text
    $SecondaryDNS   = $FormControls.TxtBoxFormMain_ServerSecondaryDns.Text
    $SelectedAdapter = $FormControls.LstBoxFormMain_ServerEthernetAdapterToUse.SelectedItem

    # Exemple : Afficher un r�capitulatif
    $msg = @"
    DOMAIN      : $DomainName
    SERVER      : $ServerName
    PASSWORD    : $ServerPassword
    IP          : $IPAddress
    MASK        : $Netmask
    GATEWAY     : $Gateway
    DNS1        : $PrimaryDNS
    DNS2        : $SecondaryDNS
    ADAPTER     : $SelectedAdapter
"@

    [System.Windows.Forms.MessageBox]::Show($msg, "Configuration r�cap:")
	
	# On renomme la machine local
	if (-not($Env:ComputerName -eq $ServerName)){
	    Rename-Computer -NewName $ServerName
	}	
	
	# V�rifie si l'adresse IPv4 est valide et diff�rente de "0.0.0.0"
	function IsValidIPv4 ($ip) {
        if ($ip -eq "0.0.0.0"){ return $False }
		return [System.Net.IPAddress]::TryParse($ip, [ref]$null)
	}

	# V�rification de la pr�sence de l'ensemble des champs du formulaire
	if (-not $DomainName -or -not $ServerName -or -not $ServerPassword -or -not $IPAddress) {
		[System.Windows.Forms.MessageBox]::Show("Merci de remplir tous les champs obligatoires.", "Champs manquants", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
		return
	}
	if (-not $Netmask -or -not $Gateway -or -not $PrimaryDNS -or -not $SecondaryDNS) {
		[System.Windows.Forms.MessageBox]::Show("Merci de remplir tous les champs obligatoires.", "Champs manquants", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
		return
	}
	if (-not $SelectedAdapter) {
        [System.Windows.Forms.MessageBox]::Show("Aucun adaptateur r�seau s�lectionn�.", "Erreur")
        return
    }
	
	# Validation des champs comportants des IPv4
	if (-not (IsValidIPv4 $IPAddress) -or -not (IsValidIPv4 $Gateway) -or -not (IsValidIPv4 $PrimaryDNS) -or -not (IsValidIPv4 $SecondaryDNS)) {
		[System.Windows.Forms.MessageBox]::Show("Adresse IP invalide.", "Erreur", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
		return
	}

    # Confirmation
    $confirmation = [System.Windows.Forms.MessageBox]::Show("Confirmer l'installation du contr�leur de domaine ?", "Confirmation", [System.Windows.Forms.MessageBoxButtons]::YesNo)
    if ($confirmation -ne "Yes") {
        return
    }
     
	# Convertion d'un mask ethernet en prefix
	function ConvertTo-PrefixLength($subnetMask) {
		$binary = ($subnetMask -split '\.') | ForEach-Object {
			[Convert]::ToString([int]$_, 2).PadLeft(8, '0')
		}
		return ($binary -join '').ToCharArray() | Where-Object { $_ -eq '1' } | Measure-Object | Select-Object -ExpandProperty Count
	}
    $PrefixLength = ConvertTo-PrefixLength $Netmask
	
	# VERIFICATION DE LA PRESENCE DU DOSSIER SCRIPT AU NIVEAU DU PROFIL UTILISATEUR, sinon on le cr��
    If ((Test-Path -Path "$env:USERPROFILE\Documents\scripts") -eq $False){
        New-Item -Path "$env:USERPROFILE\Documents\" -Name "scripts" -ItemType Directory
    }
  
	try {

        # 1. Configurer l'IP statique et des DNS

        Write-Host "Configuration de l'IP statique..."
        $ifAlias = $SelectedAdapter
        New-NetIPAddress -InterfaceAlias $ifAlias -IPAddress $IPAddress -PrefixLength $PrefixLength -DefaultGateway $Gateway -ErrorAction Stop
        Set-DnsClientServerAddress -InterfaceAlias $ifAlias -ServerAddresses $PrimaryDNS, $SecondaryDNS -ErrorAction Stop
    } 
	catch {
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.MessageBox]::Show("Erreur : $_", "�chec", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
	
@"
	  try {

          Start-Sleep -Seconds 10
          Import-Module ServerManager
          
          # 2. Installer le r�le AD DS si non install�
		    `$WinFeatureADDS = Get-WindowsFeature -Name AD-Domain-Services
		    if (`$WinFeatureADDS.Installed -eq `$false){
			    try{
				    Write-Host "Installation du r�le AD DS en cours..."
				    Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools
			    }catch{
				    Write-Host "Impossible d'installer le r�le AD DS !."
				    exit 1
			    }
		    }

		  # 3. Promotion en contr�leur de domaine
		  
		  Clear-Host
          Write-Host "Promotion en contr�leur de domaine en cours..."
		  Write-Host "Cr�ation de la f�ret en cours..." -Foregroundcolor Yellow

          Install-ADDSForest ``
            -DomainName "$DomainName" ``
            -DomainNetbiosName "$("$DomainName".Split('.')[0])" ``
            -SafeModeAdministratorPassword (ConvertTo-SecureString "$ServerPassword" -AsPlainText -Force) ``
            -InstallDNS ``
            -DatabasePath "C:\Windows\NTDS" ``
            -LogPath "C:\Windows\NTDS" ``
            -SysvolPath "C:\Windows\SYSVOL" ``
            -Force ``
	  } 
	  catch {
          Add-Type -AssemblyName System.Windows.Forms
          [System.Windows.Forms.MessageBox]::Show("Erreur : `$_", "�chec", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
      }
	  
	  if (Test-Path -Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\script_startup.bat"){
         Remove-Item -Path "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\script_startup.bat"
      }

	  # Red�marrage de la machine
		Write-Host "La configuration a �t� appliqu�e, red�marrage de la machine dans 10 secondes" -ForegroundColor Yellow
		Start-Sleep -Seconds 10
    	Restart-Computer -Force
"@ | Out-File -FilePath $env:USERPROFILE\Documents\scripts\$ScriptName
	
@"
		@echo off
		Powershell.exe -ExecutionPolicy Bypass -File "$env:USERPROFILE\Documents\scripts\$ScriptName"
"@ | Set-Content "$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup\script_startup.bat"

    Write-Host "Red�marrage imminent pour appliquer les modifications r�seau et nom d�h�te."
    Write-Host "Le script de post-red�marrage est install�, red�marrage de la machine dans 10 secondes..." -ForegroundColor Yellow

    Start-Sleep -Seconds 10
    Restart-Computer -Force
}