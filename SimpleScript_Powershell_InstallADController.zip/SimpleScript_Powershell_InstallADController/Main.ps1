# Main.ps1

# Charger les fichiers UI et Logic
. "$PSScriptRoot\UI.ps1"
. "$PSScriptRoot\Logic.ps1"

# Cr�er l'interface
$ui = Create-MyForm

# R�cup�ration des interfaces pr�sentes sur la machine h�te
$NetAdapters = Get-NetAdapter | Select-Object Name
foreach ($Adapter in $NetAdapters){
    $ui.LstBoxFormMain_ServerEthernetAdapterToUse.Items.Add($Adapter.Name) 
}
  
# Attacher les événements
$ui.BtnFormMain_InstallADDS.Add_Click({ On-Click_BtnFormMain_InstallADDS -FormControls $ui})

# Afficher le formulaire
[void]$ui.FormMain.ShowDialog()
